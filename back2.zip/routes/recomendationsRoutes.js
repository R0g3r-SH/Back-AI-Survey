import express from 'express';

import { generateRoadmap , getRecomendationsBycompanyId } from '../controllers/recomendationsController.js';

const router = express.Router();    

router.get('/:companyId', getRecomendationsBycompanyId);
router.get('/roadmap/:companyId', generateRoadmap);

export default router;